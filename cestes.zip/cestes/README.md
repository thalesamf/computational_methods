Original data from: Jeliazkov et al 2020 Sci Data https://doi.org/10.1038/s41597-019-0344-7

Downloaded from: https://idata.idiv.de/ddm/Data/ShowData/286

From all data in Jeliazkov et al 2020, we selected only data from Pavoine et al 2011 (file Pavoine2011_raw.xlsx). 

From the original xlsx file (Pavoine2011_raw.xlsx) we created five csv files from each of the following tabs: comm, traits, envir, coord, and splist, that are stored in this `cestes` folder under the names:

- comm.csv
- traits.csv
- envir.csv
- coord.csv
- splist.csv


